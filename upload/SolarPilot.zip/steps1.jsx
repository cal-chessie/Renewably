// steps1.jsx — Landing, Account, Company, Territory, Integrations
const { useState: useS1, useEffect: useE1 } = React;

// ─── Landing ────────────────────────────────────────────────────────────
function Landing({ onStart, onDemo }) {
  return (
    <div className="fade-up" style={{ padding: '8px 0' }}>
      {/* Hero row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 0.9fr', gap: 40, alignItems: 'center', marginBottom: 48 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 28 }}>
            <SunMark size={40} />
            <div>
              <div style={{ fontSize: 18, fontWeight: 600, letterSpacing: '-0.02em' }}>SolarPilot</div>
              <div className="mono" style={{ fontSize: 9.5, color: 'var(--ink-4)', letterSpacing: '0.14em', textTransform: 'uppercase', marginTop: 1, whiteSpace: 'nowrap' }}>
                by Renewably · Ireland
              </div>
            </div>
          </div>

          <div style={{ marginBottom: 18 }}>
            <div style={{ whiteSpace: 'nowrap', display: 'inline-block' }}>
              <Badge tone="solar">
                <span style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--solar)' }} />
                SEAI-aligned · Q2 2026 release
              </Badge>
            </div>
          </div>

          <h1 style={{
            fontSize: 48, fontWeight: 600,
            letterSpacing: '-0.035em', lineHeight: 1.02,
            margin: '0 0 18px',
          }}>
            Run your solar<br/>business on <span style={{ color: 'var(--solar)' }}>autopilot</span>.
          </h1>

          <p style={{
            color: 'var(--ink-3)', fontSize: 15, lineHeight: 1.55,
            margin: '0 0 28px', maxWidth: 460,
          }}>
            Operating software for Irish solar installers. Qualified leads, grant paperwork, homeowner proposals and recurring PPA earnings — in one portal.
          </p>

          <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 18 }}>
            <Button onClick={onStart} size="xl" icon={<Icon.Arrow size={14} />}>
              Start free trial
            </Button>
            <Button variant="ghost" size="xl" onClick={onDemo}>
              Book a demo
            </Button>
          </div>

          <div className="mono" style={{ fontSize: 10.5, color: 'var(--ink-4)', letterSpacing: '0.06em' }}>
            No card required · 14-day trial · Setup in under 10 minutes
          </div>
        </div>

        {/* Hero artwork — robot mascot */}
        <HeroArt />
      </div>

      {/* Value prop strip */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        borderTop: '1px solid var(--line-soft)',
        borderBottom: '1px solid var(--line-soft)',
        margin: '0 0 48px',
      }}>
        {[
          { stat: '20–30', unit: 'leads / mo', label: 'Qualified homeowners, routed to your territory' },
          { stat: '€84', unit: '/ home / yr', label: 'Passive PPA earnings, paid quarterly' },
          { stat: '11 min', unit: 'avg. setup', label: 'From signup to live portal with team + integrations' },
        ].map((v, i) => (
          <div key={i} style={{
            padding: '22px 24px',
            borderRight: i < 2 ? '1px solid var(--line-soft)' : 'none',
            minWidth: 0,
          }}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 8, flexWrap: 'wrap' }}>
              <div className="tabular" style={{ fontSize: 30, fontWeight: 600, letterSpacing: '-0.03em', color: 'var(--solar)', lineHeight: 1, whiteSpace: 'nowrap' }}>
                {v.stat}
              </div>
              <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.06em', whiteSpace: 'nowrap' }}>
                {v.unit}
              </div>
            </div>
            <div style={{ fontSize: 12.5, color: 'var(--ink-3)', lineHeight: 1.45, textWrap: 'pretty' }}>
              {v.label}
            </div>
          </div>
        ))}
      </div>

      {/* Social proof */}
      <div style={{ marginBottom: 16 }}>
        <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 14 }}>
          Trusted by installers across
        </div>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          {['Dublin', 'Cork', 'Galway', 'Limerick', 'Waterford', 'Kildare', 'Meath', 'Wicklow', '+ 24 more'].map(c => (
            <span key={c} className="mono" style={{
              fontSize: 11, color: 'var(--ink-3)',
              padding: '5px 10px',
              border: '1px solid var(--line-soft)',
              borderRadius: 4,
              background: 'var(--bg-1)',
              whiteSpace: 'nowrap',
            }}>
              {c}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

function HeroArt() {
  return (
    <div style={{
      position: 'relative', height: 420,
      borderRadius: 12,
      background: 'var(--solar)',
      border: '1px solid oklch(0.70 0.17 95 / 0.4)',
      overflow: 'hidden',
    }}>
      <img src="assets/robot-laptop.jpg" alt="SolarPilot AI Co-Pilot" style={{
        position: 'absolute', inset: 0,
        width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'right center',
      }} />
      <div style={{
        position: 'absolute', bottom: 16, left: 16, right: 16,
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6,
      }}>
        <div style={{
          background: 'rgba(10,10,10,0.82)', backdropFilter: 'blur(8px)',
          border: '1px solid rgba(255,255,255,0.08)',
          borderRadius: 8, padding: '10px 12px',
        }}>
          <div className="mono" style={{ fontSize: 9, color: 'oklch(0.72 0.008 85)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
            AI Co-Pilot
          </div>
          <div className="tabular" style={{ fontSize: 15, fontWeight: 600, color: 'white', marginTop: 2 }}>
            3 proposals drafted
          </div>
        </div>
        <div style={{
          background: 'rgba(10,10,10,0.82)', backdropFilter: 'blur(8px)',
          border: '1px solid rgba(255,255,255,0.08)',
          borderRadius: 8, padding: '10px 12px',
        }}>
          <div className="mono" style={{ fontSize: 9, color: 'oklch(0.72 0.008 85)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
            Pipeline
          </div>
          <div className="tabular" style={{ fontSize: 15, fontWeight: 600, color: 'var(--solar)', marginTop: 2 }}>
            €247k · this quarter
          </div>
        </div>
      </div>
    </div>
  );
}

function _LegacyHero_Unused() {
  return null;
}

// ─── Step 1 · Account ───────────────────────────────────────────────────
function StepAccount({ onNext }) {
  const [email, setEmail] = useS1('sean@powersolarltd.ie');
  const [pw, setPw] = useS1('Password123!');
  const [busy, setBusy] = useS1(false);
  const [agree, setAgree] = useS1(true);

  const strength = pw.length < 6 ? 1 : pw.length < 10 ? 2 : /[A-Z]/.test(pw) && /\d/.test(pw) && /[!@#$%]/.test(pw) ? 4 : 3;
  const strengthLabels = ['', 'Weak', 'Fair', 'Good', 'Strong'];
  const strengthColors = ['', 'var(--red)', 'oklch(0.78 0.13 65)', 'var(--solar)', 'var(--green)'];

  const go = () => {
    setBusy(true);
    setTimeout(() => { setBusy(false); onNext({ email }); }, 480);
  };

  return (
    <div className="fade-up">
      <SectionHead eyebrow="01 · Account" title="Create your account" desc="Free for 14 days. No credit card. You can cancel anytime, and we'll export your data." />

      <div style={{ display: 'grid', gap: 14, marginBottom: 18 }}>
        <Field label="Email address" required>
          <Input value={email} onChange={setEmail} type="email" />
        </Field>
        <Field label="Password" required hint={strength ? strengthLabels[strength] : ''}>
          <Input value={pw} onChange={setPw} type="password" />
          <div style={{ display: 'flex', gap: 3, marginTop: 6 }}>
            {[1,2,3,4].map(i => (
              <div key={i} style={{
                flex: 1, height: 2, borderRadius: 1,
                background: i <= strength ? strengthColors[strength] : 'var(--line-soft)',
                transition: 'background 160ms ease',
              }} />
            ))}
          </div>
        </Field>

        <label style={{ display: 'flex', alignItems: 'flex-start', gap: 8, cursor: 'pointer', marginTop: 4 }}>
          <input type="checkbox" checked={agree} onChange={e => setAgree(e.target.checked)} style={{ marginTop: 2 }} />
          <span style={{ fontSize: 12, color: 'var(--ink-3)', lineHeight: 1.5 }}>
            I agree to the <span style={{ color: 'var(--ink-2)', textDecoration: 'underline', textDecorationColor: 'var(--line)' }}>Renewably Terms</span> and acknowledge the{' '}
            <span style={{ color: 'var(--ink-2)', textDecoration: 'underline', textDecorationColor: 'var(--line)' }}>Privacy Notice</span>.
          </span>
        </label>
      </div>

      <div style={{ display: 'flex', gap: 10, alignItems: 'center', paddingTop: 14, borderTop: '1px solid var(--line-soft)' }}>
        <Button onClick={go} disabled={busy || !agree} size="lg" icon={<Icon.Arrow size={14} />}>
          {busy ? 'Creating account…' : 'Continue'}
        </Button>
        <div className="mono" style={{ fontSize: 10.5, color: 'var(--ink-4)', letterSpacing: '0.04em' }}>
          Already a customer? <span style={{ color: 'var(--ink-2)', textDecoration: 'underline' }}>Sign in</span>
        </div>
      </div>
    </div>
  );
}

// ─── Step 2 · Company ───────────────────────────────────────────────────
function StepCompany({ onNext, onBack }) {
  const [d, setD] = useS1({
    company_name: 'Power Solar Ltd',
    contact_name: 'Sean Power',
    phone: '087 123 4567',
    vat: 'IE9876543A',
    address: 'Unit 4, Sandyford Industrial Estate',
    city: 'Dublin',
    eircode: 'D18 FX78',
    size: '6-15',
    founded: '2019',
  });
  const set = (k, v) => setD(x => ({ ...x, [k]: v }));
  const [busy, setBusy] = useS1(false);

  const go = () => {
    setBusy(true);
    setTimeout(() => { setBusy(false); onNext({ company_name: d.company_name, contact_name: d.contact_name }); }, 400);
  };

  return (
    <div className="fade-up">
      <SectionHead eyebrow="02 · Company" title="Tell us about your company" desc="This appears on client invoices, grant applications, and PPA contracts. You can edit it anytime." />

      <div style={{ display: 'grid', gap: 14 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <Field label="Company name" required><Input value={d.company_name} onChange={v => set('company_name', v)} /></Field>
          <Field label="Primary contact" required><Input value={d.contact_name} onChange={v => set('contact_name', v)} /></Field>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <Field label="Phone" required><Input value={d.phone} onChange={v => set('phone', v)} /></Field>
          <Field label="VAT number" hint="IE format"><Input value={d.vat} onChange={v => set('vat', v)} mono /></Field>
        </div>
        <Field label="Business address" required><Input value={d.address} onChange={v => set('address', v)} /></Field>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 10 }}>
          <Field label="City"><Input value={d.city} onChange={v => set('city', v)} /></Field>
          <Field label="Eircode"><Input value={d.eircode} onChange={v => set('eircode', v)} mono /></Field>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <Field label="Team size">
            <Selector value={d.size} options={['1-5', '6-15', '16-30', '31-50', '50+']} onChange={v => set('size', v)} />
          </Field>
          <Field label="Founded"><Input value={d.founded} onChange={v => set('founded', v)} mono /></Field>
        </div>
      </div>

      <FooterBar>
        <Button variant="ghost" onClick={onBack}>Back</Button>
        <Button onClick={go} disabled={busy} icon={<Icon.Arrow size={14} />}>
          {busy ? 'Saving…' : 'Continue'}
        </Button>
      </FooterBar>
    </div>
  );
}

function Selector({ value, options, onChange }) {
  return (
    <div style={{ display: 'flex', gap: 4, padding: 3, background: 'var(--bg-1)', border: '1px solid var(--line-soft)', borderRadius: 8 }}>
      {options.map(o => (
        <button key={o} type="button" onClick={() => onChange(o)}
          className={value === o ? '' : 'mono'}
          style={{
            flex: 1, padding: '7px 8px',
            background: value === o ? 'var(--bg-3)' : 'transparent',
            color: value === o ? 'var(--ink)' : 'var(--ink-4)',
            border: 'none', borderRadius: 5,
            fontSize: value === o ? 12.5 : 11.5,
            fontWeight: value === o ? 500 : 400,
            cursor: 'pointer',
            transition: 'all 140ms ease',
            whiteSpace: 'nowrap',
            minWidth: 0,
          }}>
          {o}
        </button>
      ))}
    </div>
  );
}

// ─── Step 3 · Territory ─────────────────────────────────────────────────
function StepTerritory({ onNext, onBack }) {
  const [sel, setSel] = useS1(['Dublin','Kildare','Meath','Wicklow','Wexford','Louth']);
  const [provFilter, setProvFilter] = useS1('All');
  const tog = c => setSel(s => s.includes(c) ? s.filter(x => x !== c) : [...s, c]);
  const togProv = p => {
    const cs = PROVINCES[p];
    const allIn = cs.every(c => sel.includes(c));
    setSel(s => allIn ? s.filter(c => !cs.includes(c)) : Array.from(new Set([...s, ...cs])));
  };
  const togAll = () => setSel(s => s.length === COUNTIES.length ? [] : [...COUNTIES]);

  const visibleCounties = provFilter === 'All' ? COUNTIES : PROVINCES[provFilter];

  // Est. reach calc (playful but grounded)
  const reach = sel.length * 32; // homes/mo
  const revenue = reach * 12 * 7; // approximate annual PPA

  return (
    <div className="fade-up">
      <SectionHead eyebrow="03 · Territory" title="Where do you install?" desc="We'll route qualified homeowner leads to you within this service area. Expand or contract anytime." />

      {/* Province filter + stats */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 20, alignItems: 'stretch', marginBottom: 14 }}>
        <Card tone="raised" style={{ padding: 14 }}>
          <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 10 }}>
            Provinces
          </div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {['All', ...Object.keys(PROVINCES)].map(p => {
              const isAll = p === 'All';
              const cs = isAll ? COUNTIES : PROVINCES[p];
              const count = isAll ? sel.length : sel.filter(c => cs.includes(c)).length;
              const active = provFilter === p;
              return (
                <button key={p} type="button" onClick={() => setProvFilter(p)} style={{
                  padding: '6px 11px',
                  background: active ? 'var(--bg-3)' : 'var(--bg-1)',
                  border: `1px solid ${active ? 'var(--solar)' : 'var(--line-soft)'}`,
                  borderRadius: 6,
                  color: active ? 'var(--ink)' : 'var(--ink-3)',
                  fontSize: 12, fontWeight: 500,
                  cursor: 'pointer',
                  display: 'flex', alignItems: 'center', gap: 6,
                  transition: 'all 140ms',
                }}>
                  {p}
                  <span className="mono" style={{ fontSize: 9.5, color: active ? 'var(--solar)' : 'var(--ink-5)' }}>
                    {count}/{cs.length}
                  </span>
                </button>
              );
            })}
          </div>

          <div style={{ display: 'flex', gap: 8, marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--line-soft)' }}>
            <Button size="sm" variant="ghost" onClick={togAll}>
              {sel.length === COUNTIES.length ? 'Deselect all 26' : 'Select all 26'}
            </Button>
            {provFilter !== 'All' && (
              <Button size="sm" variant="ghost" onClick={() => togProv(provFilter)}>
                Toggle {provFilter}
              </Button>
            )}
          </div>
        </Card>

        <Card tone="solar" style={{ width: 200, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <div className="mono" style={{ fontSize: 9.5, color: 'var(--solar-ink)', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 8 }}>
            Est. reach
          </div>
          <div className="tabular" style={{ fontSize: 38, fontWeight: 600, letterSpacing: '-0.035em', color: 'var(--solar-ink)', lineHeight: 1 }}>
            {sel.length}
          </div>
          <div style={{ fontSize: 11, color: 'var(--solar-ink)', opacity: 0.75, marginTop: 4, letterSpacing: '-0.005em' }}>
            counties · ~{reach.toLocaleString()} homes/mo
          </div>
        </Card>
      </div>

      {/* County grid */}
      <Card style={{ marginBottom: 18, padding: 16 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
            Counties {provFilter !== 'All' && `· ${provFilter}`}
          </div>
          <div className="mono" style={{ fontSize: 10, color: 'var(--ink-5)' }}>
            {sel.filter(c => visibleCounties.includes(c)).length} of {visibleCounties.length} selected
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 4 }}>
          {visibleCounties.map(c => {
            const on = sel.includes(c);
            return (
              <label key={c} style={{
                display: 'flex', alignItems: 'center', gap: 8,
                padding: '7px 10px',
                border: `1px solid ${on ? 'oklch(0.70 0.17 95 / 0.35)' : 'var(--line-soft)'}`,
                background: on ? 'var(--solar-soft)' : 'var(--bg-1)',
                borderRadius: 6, cursor: 'pointer',
                fontSize: 12,
                color: on ? 'var(--solar-ink)' : 'var(--ink-2)',
                transition: 'all 140ms ease',
              }}>
                <input type="checkbox" checked={on} onChange={() => tog(c)} />
                <span style={{ fontWeight: on ? 500 : 400 }}>{c}</span>
              </label>
            );
          })}
        </div>
      </Card>

      <FooterBar>
        <Button variant="ghost" onClick={onBack}>Back</Button>
        <Button onClick={() => onNext({ counties: sel })} disabled={sel.length === 0} icon={<Icon.Arrow size={14} />}>
          Continue with {sel.length} {sel.length === 1 ? 'county' : 'counties'}
        </Button>
      </FooterBar>
    </div>
  );
}

// ─── Step 4 · Integrations ──────────────────────────────────────────────
function StepIntegrations({ onNext, onBack }) {
  const [conn, setConn] = useS1({ seai: 'done' });
  const [filter, setFilter] = useS1('All');
  const items = [
    // Grants / regulation
    { id: 'seai', name: 'SEAI Grant Portal', desc: 'Homeowner grant applications & BER submissions', cat: 'Grants', domain: 'seai.ie', popular: true, fee: 0 },
    { id: 'esb',  name: 'ESB Networks NC6', desc: 'Micro-generation export notifications', cat: 'Grants', domain: 'esbnetworks.ie', popular: true, fee: 120 },
    { id: 'mprn', name: 'MPRN Lookup', desc: 'Verify meter numbers against ESB register', cat: 'Grants', domain: 'mprnsearch.ie', fee: 40 },

    // Hardware / monitoring
    { id: 'solis',     name: 'Solis Cloud',         desc: 'Monitor installed Solis inverters', cat: 'Hardware', domain: 'solisinverters.com', popular: true, fee: 180 },
    { id: 'solaredge', name: 'SolarEdge Monitoring', desc: 'Optimiser-level performance data', cat: 'Hardware', domain: 'solaredge.com', popular: true, fee: 220 },
    { id: 'fronius',   name: 'Fronius Solar.web',   desc: 'Fronius inverter fleet & alerts', cat: 'Hardware', domain: 'fronius.com', fee: 180 },
    { id: 'huawei',    name: 'Huawei FusionSolar',  desc: 'Residential & battery monitoring', cat: 'Hardware', domain: 'solar.huawei.com', fee: 180 },
    { id: 'growatt',   name: 'Growatt ShinePhone',  desc: 'Entry-tier inverter monitoring', cat: 'Hardware', domain: 'growatt.com', fee: 140 },
    { id: 'tesla',     name: 'Tesla Powerwall',     desc: 'Battery status via Tesla API', cat: 'Hardware', domain: 'tesla.com', fee: 260 },

    // Design & survey
    { id: 'aurora',    name: 'Aurora Solar', desc: 'Roof design, shading, performance sims', cat: 'Design', domain: 'aurorasolar.com', popular: true, fee: 280 },
    { id: 'openSolar', name: 'OpenSolar',    desc: 'Free 3D proposal & design tool', cat: 'Design', domain: 'opensolar.com', fee: 120 },
    { id: 'nearmap',   name: 'Nearmap',      desc: 'High-res aerial imagery of Irish rooftops', cat: 'Design', domain: 'nearmap.com', fee: 160 },

    // Finance & accounting
    { id: 'xero',       name: 'Xero',            desc: 'Accounting + VAT 3 / RCT returns', cat: 'Finance', domain: 'xero.com', popular: true, fee: 150 },
    { id: 'surf',       name: 'Surf Accounts',   desc: 'Irish SME accounting, CSO-aligned', cat: 'Finance', domain: 'surfaccounts.com', fee: 150 },
    { id: 'sage',       name: 'Sage Business',   desc: 'Payroll + accounting suite', cat: 'Finance', domain: 'sage.com', fee: 180 },
    { id: 'stripe',     name: 'Stripe',          desc: 'Deposits, subscriptions, refunds', cat: 'Finance', domain: 'stripe.com', popular: true, fee: 90 },
    { id: 'gocardless', name: 'GoCardless',      desc: 'SEPA direct debit for PPA customers', cat: 'Finance', domain: 'gocardless.com', fee: 110 },
    { id: 'revenue',    name: 'ROS (Revenue.ie)', desc: 'RCT subbie notifications, VAT returns', cat: 'Finance', domain: 'revenue.ie', fee: 240 },

    // CRM / pipeline
    { id: 'hubspot',    name: 'HubSpot',    desc: 'Sync contacts, pipelines, sequences', cat: 'CRM', domain: 'hubspot.com', fee: 200 },
    { id: 'pipedrive',  name: 'Pipedrive',  desc: 'Deal pipeline + activities', cat: 'CRM', domain: 'pipedrive.com', fee: 180 },
    { id: 'salesforce', name: 'Salesforce', desc: 'Enterprise CRM sync', cat: 'CRM', domain: 'salesforce.com', fee: 420 },

    // Communications & productivity
    { id: 'gmail',    name: 'Google Workspace', desc: 'Gmail, Calendar, Drive, Meet', cat: 'Comms', domain: 'workspace.google.com', popular: true, fee: 60 },
    { id: 'ms365',    name: 'Microsoft 365',    desc: 'Outlook, Teams, SharePoint', cat: 'Comms', domain: 'microsoft365.com', fee: 80 },
    { id: 'whatsapp', name: 'WhatsApp Business', desc: 'Homeowner messaging on the channel they use', cat: 'Comms', domain: 'business.whatsapp.com', popular: true, fee: 140 },
    { id: 'twilio',   name: 'Twilio SMS',       desc: 'Appointment + install-day reminders', cat: 'Comms', domain: 'twilio.com', fee: 110 },
    { id: 'postmark', name: 'Postmark',         desc: 'Transactional email delivery', cat: 'Comms', domain: 'postmarkapp.com', fee: 60 },

    // Field ops
    { id: 'servicem8',  name: 'ServiceM8',    desc: 'Install scheduling & job sheets', cat: 'Field ops', domain: 'servicem8.com', fee: 160 },
    { id: 'fergus',     name: 'Fergus',       desc: 'Job management for trades', cat: 'Field ops', domain: 'fergus.com', fee: 160 },
    { id: 'companycam', name: 'CompanyCam',   desc: 'Time-stamped site + install photos', cat: 'Field ops', domain: 'companycam.com', fee: 90 },
  ];
  const cats = ['All', 'Grants', 'Hardware', 'Design', 'Finance', 'CRM', 'Comms', 'Field ops'];
  const doConn = id => {
    setConn(c => ({ ...c, [id]: 'busy' }));
    setTimeout(() => setConn(c => ({ ...c, [id]: 'done' })), 700 + Math.random() * 400);
  };

  const connectedCount = Object.values(conn).filter(v => v === 'done').length;
  const setupTotal = items.reduce((sum, it) => conn[it.id] === 'done' ? sum + it.fee : sum, 0);
  const filtered = filter === 'All' ? items : items.filter(i => i.cat === filter);
  const counts = cats.reduce((acc, c) => {
    acc[c] = c === 'All' ? items.length : items.filter(i => i.cat === c).length;
    return acc;
  }, {});

  return (
    <div className="fade-up">
      <SectionHead eyebrow="04 · Tools" title="Connect your stack" desc="Each integration includes a one-off setup fee covering migration, field mapping, and go-live testing. SEAI is pre-linked via your RGI registration." />

      {/* Category tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 14, flexWrap: 'wrap', padding: 3, background: 'var(--bg-1)', border: '1px solid var(--line-soft)', borderRadius: 8 }}>
        {cats.map(c => {
          const on = filter === c;
          return (
            <button key={c} type="button" onClick={() => setFilter(c)} style={{
              padding: '6px 11px',
              background: on ? 'var(--bg-3)' : 'transparent',
              color: on ? 'var(--ink)' : 'var(--ink-4)',
              border: 'none', borderRadius: 5,
              fontSize: 11.5, fontWeight: on ? 500 : 400,
              cursor: 'pointer', fontFamily: 'inherit',
              display: 'inline-flex', alignItems: 'center', gap: 6,
              whiteSpace: 'nowrap',
            }}>
              {c}
              <span className="mono" style={{ fontSize: 10, color: on ? 'var(--ink-4)' : 'var(--ink-5)' }}>{counts[c]}</span>
            </button>
          );
        })}
      </div>

      <div style={{ display: 'grid', gap: 6, marginBottom: 16 }}>
        {filtered.map((it, i) => {
          const state = conn[it.id];
          return (
            <div key={it.id} style={{
              display: 'grid', gridTemplateColumns: '32px 1fr auto auto',
              alignItems: 'center', gap: 12,
              padding: '10px 14px',
              background: 'var(--bg-1)',
              border: '1px solid var(--line-soft)',
              borderRadius: 8,
            }}>
              <div style={{
                width: 32, height: 32,
                background: '#fff',
                border: '1px solid var(--line-soft)',
                borderRadius: 6,
                display: 'grid', placeItems: 'center',
                overflow: 'hidden',
                position: 'relative',
              }}>
                <img
                  src={`https://www.google.com/s2/favicons?sz=64&domain=${it.domain}`}
                  alt=""
                  width="22" height="22"
                  style={{ display: 'block', objectFit: 'contain' }}
                  onError={e => {
                    const el = e.currentTarget;
                    el.style.display = 'none';
                    const fb = el.nextSibling;
                    if (fb) fb.style.display = 'grid';
                  }}
                />
                <span style={{
                  display: 'none',
                  position: 'absolute', inset: 0,
                  placeItems: 'center',
                  color: 'var(--ink-2)', background: 'var(--bg-2)',
                  fontFamily: 'Geist Mono, monospace',
                  fontSize: 12, fontWeight: 600,
                }}>
                  {it.name[0]}
                </span>
              </div>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 500, letterSpacing: '-0.01em', display: 'flex', alignItems: 'center', gap: 8 }}>
                  {it.name}
                  {it.popular && <span className="mono" style={{ fontSize: 9, color: 'var(--solar)', letterSpacing: '0.08em', textTransform: 'uppercase', padding: '1px 5px', border: '1px solid oklch(0.70 0.17 95 / 0.3)', borderRadius: 3, background: 'var(--solar-soft)' }}>Popular</span>}
                </div>
                <div style={{ fontSize: 11.5, color: 'var(--ink-4)', marginTop: 1 }}>{it.desc}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div className="mono tabular" style={{
                  fontSize: 12.5, fontWeight: 500,
                  color: it.fee === 0 ? 'var(--green)' : 'var(--ink-2)',
                  letterSpacing: '-0.01em',
                }}>
                  {it.fee === 0 ? 'Free' : `€${it.fee}`}
                </div>
                <div className="mono" style={{ fontSize: 9, color: 'var(--ink-5)', letterSpacing: '0.08em', textTransform: 'uppercase', marginTop: 2 }}>
                  {it.fee === 0 ? 'Included' : 'one-off'}
                </div>
              </div>
              <button type="button" onClick={() => state !== 'done' && doConn(it.id)} disabled={!!state}
                style={{
                  background: state === 'done' ? 'var(--green-soft)' : 'transparent',
                  color: state === 'done' ? 'var(--green)' : 'var(--ink-2)',
                  border: `1px solid ${state === 'done' ? 'oklch(0.76 0.17 145 / 0.3)' : 'var(--line-soft)'}`,
                  borderRadius: 6,
                  padding: '6px 12px',
                  fontSize: 11.5, fontWeight: 500,
                  cursor: state ? 'default' : 'pointer',
                  fontFamily: 'inherit',
                  minWidth: 100,
                  display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                  transition: 'all 160ms',
                }}>
                {state === 'done' ? (<><Icon.Check size={11} /> Connected</>) : state === 'busy' ? (<span className="pulse">Connecting…</span>) : 'Connect'}
              </button>
            </div>
          );
        })}
      </div>

      <div style={{
        display: 'grid', gridTemplateColumns: '1fr auto', gap: 20, alignItems: 'center',
        padding: '14px 16px',
        background: 'var(--bg-2)',
        border: '1px solid var(--line-soft)',
        borderRadius: 10,
        marginBottom: 16,
      }}>
        <div>
          <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 4 }}>
            Setup summary
          </div>
          <div style={{ fontSize: 12.5, color: 'var(--ink-3)', lineHeight: 1.45 }}>
            <span style={{ color: 'var(--green)' }}>●</span> {connectedCount} of {items.length} connected
            <span style={{ color: 'var(--ink-5)', margin: '0 8px' }}>·</span>
            Setup fees cover white-glove migration, field-mapping & go-live testing per integration.
            <span style={{ color: 'var(--ink-5)', margin: '0 6px' }}>·</span>
            <span style={{ color: 'var(--ink-4)' }}>Billed once, after go-live.</span>
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 2 }}>
            One-off setup total
          </div>
          <div className="mono tabular" style={{ fontSize: 22, fontWeight: 600, color: 'var(--ink)', letterSpacing: '-0.02em' }}>
            €{setupTotal.toLocaleString('en-IE')}
          </div>
          <div className="mono" style={{ fontSize: 10, color: 'var(--ink-5)', letterSpacing: '0.06em', marginTop: 1 }}>
            + €149/mo base · incl. VAT
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', marginBottom: 16 }}>
        <div className="mono" style={{ color: 'var(--ink-5)', fontSize: 10.5, letterSpacing: '0.06em' }}>
          Don't see yours? <span style={{ color: 'var(--solar)', textDecoration: 'underline', cursor: 'pointer' }}>Request an integration</span>
        </div>
      </div>

      <FooterBar>
        <Button variant="ghost" onClick={onBack}>Back</Button>
        <Button variant="quiet" onClick={() => onNext({ setupTotal: 0, connectedIds: [] })}>Skip for now</Button>
        <Button onClick={() => onNext({ setupTotal, connectedIds: Object.keys(conn).filter(k => conn[k] === 'done') })} icon={<Icon.Arrow size={14} />}>Continue</Button>
      </FooterBar>
    </div>
  );
}

// ─── Footer bar ──────────────────────────────────────────────────────────
function FooterBar({ children }) {
  return (
    <div style={{
      display: 'flex', gap: 10, alignItems: 'center',
      paddingTop: 20, marginTop: 20,
      borderTop: '1px solid var(--line-soft)',
      justifyContent: 'flex-end',
    }}>
      {children}
    </div>
  );
}

Object.assign(window, { Landing, StepAccount, StepCompany, StepTerritory, StepIntegrations, FooterBar });

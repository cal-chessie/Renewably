// steps2.jsx — Legal, Financial, Technical, Welcome, Complete
const { useState: useS2, useEffect: useE2, useRef: useR2 } = React;

// ─── Step 5 · Legal ─────────────────────────────────────────────────────
function StepLegal({ onNext, onBack }) {
  const [signed, setSigned] = useS2({});
  const [busy, setBusy] = useS2(false);
  const [viewingDoc, setViewingDoc] = useS2(null);
  const allDone = DOCS.every(d => signed[d.id]);

  const signAll = () => {
    setBusy(true);
    let i = 0;
    const timer = setInterval(() => {
      if (i >= DOCS.length) {
        clearInterval(timer);
        setBusy(false);
        return;
      }
      const doc = DOCS[i];
      i++;
      setSigned(s => ({ ...s, [doc.id]: true }));
      if (i >= DOCS.length) {
        clearInterval(timer);
        setBusy(false);
      }
    }, 380);
  };

  return (
    <div className="fade-up">
      <SectionHead eyebrow="05 · Legal" title="Legal agreements" desc="Review and sign to proceed. Copies will be sent to your email and stored in your portal under Settings → Documents." />

      <div style={{ display: 'grid', gap: 8, marginBottom: 18 }}>
        {DOCS.map(doc => {
          const isSigned = signed[doc.id];
          return (
            <div key={doc.id} style={{
              display: 'grid', gridTemplateColumns: '36px 1fr auto auto',
              alignItems: 'center', gap: 14,
              padding: '12px 14px',
              background: isSigned ? 'var(--green-soft)' : 'var(--bg-1)',
              border: `1px solid ${isSigned ? 'oklch(0.76 0.17 145 / 0.25)' : 'var(--line-soft)'}`,
              borderRadius: 8,
              transition: 'all 300ms ease',
            }}>
              <div style={{
                width: 36, height: 36, borderRadius: 4,
                background: 'var(--bg-2)',
                border: '1px solid var(--line-soft)',
                display: 'grid', placeItems: 'center',
                color: isSigned ? 'var(--green)' : 'var(--ink-3)',
              }}>
                <Icon.Doc size={16} />
              </div>
              <div>
                <div style={{ fontSize: 13.5, fontWeight: 500, letterSpacing: '-0.01em', display: 'flex', alignItems: 'center', gap: 8 }}>
                  {doc.name}
                  {isSigned && <Badge tone="green"><Icon.Check size={9} /> Signed</Badge>}
                </div>
                <div style={{ fontSize: 11.5, color: 'var(--ink-4)', marginTop: 2 }}>{doc.desc}</div>
              </div>
              <div className="mono" style={{ fontSize: 10, color: 'var(--ink-5)' }}>{doc.pages} pp</div>
              <button type="button" onClick={() => setViewingDoc(doc)}
                style={{
                  background: 'transparent', border: '1px solid var(--line-soft)',
                  color: 'var(--ink-2)', borderRadius: 6,
                  padding: '6px 12px', fontSize: 12, fontWeight: 500, cursor: 'pointer',
                  fontFamily: 'inherit',
                }}>
                Preview
              </button>
            </div>
          );
        })}
      </div>

      {viewingDoc && (
        <div onClick={() => setViewingDoc(null)} style={{
          position: 'fixed', inset: 0, zIndex: 100,
          background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(6px)',
          display: 'grid', placeItems: 'center',
          animation: 'fadeUp 200ms ease',
        }}>
          <div onClick={e => e.stopPropagation()} style={{
            width: 520, maxHeight: '80vh',
            background: 'var(--bg-1)', border: '1px solid var(--line)',
            borderRadius: 10, overflow: 'hidden',
            display: 'flex', flexDirection: 'column',
          }}>
            <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--line-soft)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{viewingDoc.name}</div>
                <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)' }}>{viewingDoc.pages} pages · Rev. Apr 2026</div>
              </div>
              <button type="button" onClick={() => setViewingDoc(null)}
                style={{ background: 'transparent', border: 'none', color: 'var(--ink-3)', fontSize: 18, cursor: 'pointer' }}>×</button>
            </div>
            <div style={{ padding: 20, overflowY: 'auto', fontSize: 11.5, color: 'var(--ink-3)', lineHeight: 1.7 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)', marginBottom: 10 }}>1. Definitions</div>
              <p style={{ margin: '0 0 12px' }}>In this Agreement, "Service" means the SolarPilot platform provided by Renewably Ltd to the Customer under the terms hereof…</p>
              <div className="img-placeholder" style={{ height: 60, marginBottom: 12 }}>DOCUMENT BODY · PLACEHOLDER</div>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)', marginBottom: 10 }}>2. Term and termination</div>
              <p style={{ margin: '0 0 12px' }}>This Agreement shall commence on the Effective Date and continue until terminated in accordance with clause 8…</p>
              <div className="img-placeholder" style={{ height: 80 }}>DOCUMENT BODY · PLACEHOLDER</div>
            </div>
            <div style={{ padding: 14, borderTop: '1px solid var(--line-soft)', display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <Button variant="ghost" size="sm" onClick={() => setViewingDoc(null)}>Close</Button>
              <Button size="sm" onClick={() => { setSigned(s => ({ ...s, [viewingDoc.id]: true })); setViewingDoc(null); }}>
                Agree & sign
              </Button>
            </div>
          </div>
        </div>
      )}

      <FooterBar>
        <Button variant="ghost" onClick={onBack}>Back</Button>
        {allDone
          ? <Button onClick={() => onNext()} icon={<Icon.Arrow size={14} />}>Continue to finance</Button>
          : <Button onClick={signAll} disabled={busy} icon={<Icon.Check size={12} />}>
              {busy ? 'Signing…' : `Sign all ${DOCS.length} documents`}
            </Button>
        }
      </FooterBar>
    </div>
  );
}

// ─── Step 6 · Financial ─────────────────────────────────────────────────
function StepFinancial({ onNext, onBack, data }) {
  const [sub, setSub] = useS2(1);
  const [plan, setPlan] = useS2('pro');
  const [billing, setBilling] = useS2('annual');
  const setupTotal = (data && data.setupTotal) || 0;
  const connectedIds = (data && data.connectedIds) || [];

  const selectedPlan = PLANS.find(p => p.id === plan);
  const annualMult = billing === 'annual' ? 10 : 12;

  if (sub === 1) return (
    <div className="fade-up">
      <SectionHead eyebrow="06 · Finance · 1 of 3" title="Select a plan" desc="Change or cancel anytime. Annual billing saves you two months." />

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 18 }}>
        {PLANS.map(p => {
          const active = plan === p.id;
          return (
            <div key={p.id} onClick={() => setPlan(p.id)} style={{
              position: 'relative',
              background: active ? 'var(--bg-2)' : 'var(--bg-1)',
              border: `1px solid ${active ? 'var(--solar)' : 'var(--line-soft)'}`,
              borderRadius: 10, padding: 18,
              cursor: 'pointer',
              transition: 'all 180ms ease',
              boxShadow: active ? '0 0 0 3px oklch(0.85 0.17 95 / 0.1)' : 'none',
            }}>
              {p.popular && (
                <div style={{
                  position: 'absolute', top: -1, right: 14,
                  background: 'var(--solar)', color: 'var(--bg)',
                  fontSize: 9, fontWeight: 600, letterSpacing: '0.08em',
                  padding: '3px 7px', borderRadius: '0 0 3px 3px',
                  fontFamily: 'Geist Mono, monospace',
                  textTransform: 'uppercase',
                }}>
                  Most popular
                </div>
              )}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 500, letterSpacing: '-0.01em' }}>{p.name}</div>
                  <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', marginTop: 2, letterSpacing: '0.04em' }}>{p.tagline}</div>
                </div>
                <div style={{
                  width: 16, height: 16, borderRadius: '50%',
                  border: `1px solid ${active ? 'var(--solar)' : 'var(--line)'}`,
                  background: active ? 'var(--solar)' : 'transparent',
                  display: 'grid', placeItems: 'center',
                  transition: 'all 140ms ease',
                }}>
                  {active && <div style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--bg)' }} />}
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginBottom: 14 }}>
                <span className="tabular" style={{ fontSize: 30, fontWeight: 600, letterSpacing: '-0.03em', color: active ? 'var(--solar)' : 'var(--ink)' }}>
                  €{p.price}
                </span>
                <span className="mono" style={{ fontSize: 11, color: 'var(--ink-4)' }}>/mo</span>
              </div>
              <div style={{ height: 1, background: 'var(--line-soft)', marginBottom: 12 }} />
              <ul style={{ margin: 0, padding: 0, listStyle: 'none' }}>
                {p.feat.map(f => (
                  <li key={f} style={{ display: 'flex', gap: 8, fontSize: 11.5, color: 'var(--ink-3)', marginBottom: 6, lineHeight: 1.35 }}>
                    <span style={{ color: active ? 'var(--solar)' : 'var(--ink-4)', flexShrink: 0, marginTop: 2 }}>
                      <Icon.Check size={10} />
                    </span>
                    {f}
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>

      <Card style={{ padding: 14, marginBottom: 18 }}>
        <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 10 }}>
          Billing cycle
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          {[
            { v: 'monthly', l: 'Monthly', sub: `€${selectedPlan.price}/mo, billed monthly`, savings: null },
            { v: 'annual', l: 'Annual', sub: `€${selectedPlan.price * 10}/yr, billed up front`, savings: `Save €${selectedPlan.price * 2}/yr` },
          ].map(b => {
            const on = billing === b.v;
            return (
              <label key={b.v} style={{
                display: 'flex', gap: 10, alignItems: 'flex-start',
                padding: '12px 14px',
                background: on ? 'var(--solar-soft)' : 'var(--bg-1)',
                border: `1px solid ${on ? 'oklch(0.70 0.17 95 / 0.35)' : 'var(--line-soft)'}`,
                borderRadius: 8, cursor: 'pointer',
                transition: 'all 140ms',
              }}>
                <input type="radio" name="billing" checked={on} onChange={() => setBilling(b.v)} style={{ marginTop: 2 }} />
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 13, fontWeight: 500 }}>{b.l}</span>
                    {b.savings && <Badge tone="solar">{b.savings}</Badge>}
                  </div>
                  <div className="mono" style={{ fontSize: 10.5, color: 'var(--ink-4)', marginTop: 3 }}>{b.sub}</div>
                </div>
              </label>
            );
          })}
        </div>
      </Card>

      <FooterBar>
        <Button variant="ghost" onClick={onBack}>Back</Button>
        <Button onClick={() => setSub(2)} icon={<Icon.Arrow size={14} />}>Continue to billing</Button>
      </FooterBar>
    </div>
  );

  if (sub === 2) return (
    <div className="fade-up">
      <SectionHead eyebrow="06 · Finance · 2 of 3" title="Billing details" desc="Used for invoices and VAT compliance." />

      <div style={{ display: 'grid', gap: 14, marginBottom: 18 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 10 }}>
          <Field label="VAT number"><Input value="IE9876543A" onChange={() => {}} mono /></Field>
          <Field label="Invoice email" required><Input value="accounts@powersolarltd.ie" onChange={() => {}} /></Field>
        </div>
        <Field label="Billing address" required><Input value="Unit 4, Sandyford Industrial Estate" onChange={() => {}} /></Field>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
          <Field label="City"><Input value="Dublin" onChange={() => {}} /></Field>
          <Field label="County"><Input value="Dublin" onChange={() => {}} /></Field>
          <Field label="Eircode"><Input value="D18 FX78" onChange={() => {}} mono /></Field>
        </div>
        <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
          <input type="checkbox" defaultChecked />
          <span style={{ fontSize: 12, color: 'var(--ink-3)' }}>Billing address is the same as business address</span>
        </label>
      </div>

      <FooterBar>
        <Button variant="ghost" onClick={() => setSub(1)}>Back</Button>
        <Button onClick={() => setSub(3)} icon={<Icon.Arrow size={14} />}>Continue to payment</Button>
      </FooterBar>
    </div>
  );

  // sub 3 — payment
  return (
    <div className="fade-up">
      <SectionHead eyebrow="06 · Finance · 3 of 3" title="Payment method" desc="Securely processed by Stripe. You won't be charged until your trial ends on 3 May 2026." />

      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 16, marginBottom: 18 }}>
        <Card style={{ padding: 18 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
              Card details
            </div>
            <Badge tone="neutral"><Icon.Lock size={9} /> Stripe-secured</Badge>
          </div>
          <div style={{ display: 'grid', gap: 10 }}>
            <Field label="Card number" mono>
              <Input value="4242 4242 4242 4242" onChange={() => {}} mono />
            </Field>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
              <Field label="Expiry" mono><Input value="12 / 28" onChange={() => {}} mono /></Field>
              <Field label="CVC" mono><Input value="•••" onChange={() => {}} mono /></Field>
              <Field label="Country"><Input value="Ireland" onChange={() => {}} /></Field>
            </div>
            <Field label="Name on card"><Input value="Sean Power" onChange={() => {}} /></Field>
          </div>
        </Card>

        <Card tone="raised" style={{ padding: 18, display: 'flex', flexDirection: 'column' }}>
          <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 12 }}>
            Order summary
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
            <span style={{ fontSize: 13 }}>{selectedPlan.name} · {billing}</span>
            <span className="tabular" style={{ fontSize: 13, fontWeight: 500 }}>€{selectedPlan.price * annualMult}</span>
          </div>
          {setupTotal > 0 && (
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
              <span style={{ fontSize: 13 }}>Integration setup <span className="mono" style={{ fontSize: 10, color: 'var(--ink-5)', marginLeft: 4 }}>× {connectedIds.length}</span></span>
              <span className="tabular" style={{ fontSize: 13, fontWeight: 500 }}>€{setupTotal.toLocaleString('en-IE')}</span>
            </div>
          )}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
            <span className="mono" style={{ fontSize: 11, color: 'var(--ink-4)' }}>VAT (23%)</span>
            <span className="tabular mono" style={{ fontSize: 11, color: 'var(--ink-3)' }}>€{Math.round((selectedPlan.price * annualMult + setupTotal) * 0.23)}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
            <span className="mono" style={{ fontSize: 11, color: 'var(--ink-4)' }}>Trial credit (14 d)</span>
            <span className="tabular mono" style={{ fontSize: 11, color: 'var(--green)' }}>−€{Math.round(selectedPlan.price * annualMult * 0.23 / 3)}</span>
          </div>
          <div style={{ height: 1, background: 'var(--line-soft)', marginBottom: 12 }} />
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 4 }}>
            <span style={{ fontSize: 13, fontWeight: 500 }}>Total today</span>
            <span className="tabular" style={{ fontSize: 22, fontWeight: 600, color: 'var(--solar)' }}>€0.00</span>
          </div>
          <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)' }}>
            First charge 19 May 2026
            {setupTotal > 0 && <> · Setup billed after go-live</>}
          </div>
          <div style={{ flex: 1 }} />
          <div style={{ height: 1, background: 'var(--line-soft)', margin: '14px 0' }} />
          <div style={{ fontSize: 11, color: 'var(--ink-4)', lineHeight: 1.5 }}>
            Cancel anytime from Settings. Unused trial time is never charged.
          </div>
        </Card>
      </div>

      <FooterBar>
        <Button variant="ghost" onClick={() => setSub(2)}>Back</Button>
        <Button onClick={() => onNext()} icon={<Icon.Arrow size={14} />}>Confirm & start trial</Button>
      </FooterBar>
    </div>
  );
}

// ─── Step 7 · Technical ─────────────────────────────────────────────────
function StepTechnical({ onNext, onBack }) {
  const [team, setTeam] = useS2([
    { n: 'Sean Power', e: 'sean@powersolarltd.ie', r: 'Admin' },
    { n: 'Emma Byrne', e: 'emma@powersolarltd.ie', r: 'Consultant' },
  ]);
  const [ints, setInts] = useS2(['Solis', 'Stripe', 'Google Workspace']);
  const [sec, setSec] = useS2(['Audit logs', 'SSO required']);
  const [retention, setRetention] = useS2(24);

  const allInts = ['Solis','Enphase','SolarEdge','Stripe','QuickBooks','Xero','Google Workspace','Slack','Zapier','HubSpot'];
  const allSec = [
    { v: 'SSO required', d: 'Require Google / Microsoft SSO' },
    { v: 'IP whitelisting', d: 'Restrict logins to office IPs' },
    { v: 'Audit logs', d: 'Track every data change for 12 mo' },
    { v: 'Custom roles', d: 'Define per-team permissions' },
    { v: '2FA enforcement', d: 'Require 2FA for all seats' },
  ];

  const togI = v => setInts(l => l.includes(v) ? l.filter(x => x !== v) : [...l, v]);
  const togS = v => setSec(l => l.includes(v) ? l.filter(x => x !== v) : [...l, v]);
  const addSeat = () => setTeam(t => [...t, { n: '', e: '', r: 'Consultant' }]);
  const rmSeat = i => setTeam(t => t.filter((_, idx) => idx !== i));

  return (
    <div className="fade-up">
      <SectionHead eyebrow="07 · Tech" title="Technical setup" desc="Team seats, integrations, and security posture. All adjustable later." />

      {/* Team */}
      <Card style={{ padding: 16, marginBottom: 12 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
            Team · {team.length} seats
          </div>
          <div className="mono" style={{ fontSize: 10, color: 'var(--ink-5)' }}>
            5 included · €29/seat after
          </div>
        </div>
        <div style={{ display: 'grid', gap: 6 }}>
          {team.map((u, i) => (
            <div key={i} style={{
              display: 'grid', gridTemplateColumns: '1.2fr 1.4fr 140px 32px', gap: 6,
              alignItems: 'center',
            }}>
              <Input value={u.n} onChange={v => setTeam(t => t.map((x, idx) => idx === i ? { ...x, n: v } : x))} placeholder="Full name" />
              <Input value={u.e} onChange={v => setTeam(t => t.map((x, idx) => idx === i ? { ...x, e: v } : x))} placeholder="email@company.ie" />
              <Selector value={u.r} options={['Admin', 'Consultant', 'Viewer']} onChange={v => setTeam(t => t.map((x, idx) => idx === i ? { ...x, r: v } : x))} />
              <button type="button" onClick={() => rmSeat(i)} disabled={i === 0} style={{
                background: 'transparent', border: '1px solid var(--line-soft)',
                color: 'var(--ink-4)', borderRadius: 6, width: 32, height: 32,
                cursor: i === 0 ? 'not-allowed' : 'pointer', opacity: i === 0 ? 0.3 : 1,
                display: 'grid', placeItems: 'center', fontSize: 14,
              }}>×</button>
            </div>
          ))}
        </div>
        <button type="button" onClick={addSeat} style={{
          marginTop: 10, padding: '8px 12px',
          background: 'transparent', border: '1px dashed var(--line)',
          color: 'var(--ink-3)', borderRadius: 6,
          fontSize: 12, fontWeight: 500, cursor: 'pointer',
          fontFamily: 'inherit', width: '100%',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6,
        }}>
          <Icon.Plus size={11} /> Add team member
        </button>
      </Card>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 18 }}>
        {/* Integrations */}
        <Card style={{ padding: 16 }}>
          <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 12 }}>
            Integrations ({ints.length})
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4 }}>
            {allInts.map(o => {
              const on = ints.includes(o);
              return (
                <label key={o} style={{
                  display: 'flex', alignItems: 'center', gap: 7,
                  padding: '6px 8px', borderRadius: 5,
                  fontSize: 11.5, cursor: 'pointer',
                  color: on ? 'var(--ink)' : 'var(--ink-3)',
                  background: on ? 'var(--bg-2)' : 'transparent',
                  transition: 'all 120ms',
                }}>
                  <input type="checkbox" checked={on} onChange={() => togI(o)} />
                  {o}
                </label>
              );
            })}
          </div>
        </Card>

        {/* Security */}
        <Card style={{ padding: 16 }}>
          <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 12 }}>
            Security ({sec.length})
          </div>
          <div style={{ display: 'grid', gap: 4 }}>
            {allSec.map(o => {
              const on = sec.includes(o.v);
              return (
                <label key={o.v} style={{
                  display: 'flex', alignItems: 'flex-start', gap: 8,
                  padding: '7px 8px', borderRadius: 5,
                  cursor: 'pointer',
                  background: on ? 'var(--bg-2)' : 'transparent',
                  transition: 'all 120ms',
                }}>
                  <input type="checkbox" checked={on} onChange={() => togS(o.v)} style={{ marginTop: 2 }} />
                  <div>
                    <div style={{ fontSize: 11.5, color: on ? 'var(--ink)' : 'var(--ink-2)', fontWeight: on ? 500 : 400 }}>{o.v}</div>
                    <div style={{ fontSize: 10.5, color: 'var(--ink-4)', marginTop: 1 }}>{o.d}</div>
                  </div>
                </label>
              );
            })}
          </div>
        </Card>
      </div>

      {/* Data retention slider */}
      <Card style={{ padding: 16, marginBottom: 18 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
            Data retention
          </div>
          <div className="mono tabular" style={{ fontSize: 12, color: 'var(--solar)', fontWeight: 500 }}>
            {retention} months
          </div>
        </div>
        <input type="range" min={6} max={84} step={6} value={retention}
          onChange={e => setRetention(parseInt(e.target.value))}
          style={{ width: '100%', accentColor: 'var(--solar)' }} />
        <div className="mono" style={{ display: 'flex', justifyContent: 'space-between', fontSize: 9.5, color: 'var(--ink-5)', marginTop: 4 }}>
          <span>6 mo</span><span>GDPR min. 24 mo</span><span>84 mo</span>
        </div>
      </Card>

      <FooterBar>
        <Button variant="ghost" onClick={onBack}>Back</Button>
        <Button onClick={() => onNext()} icon={<Icon.Arrow size={14} />}>Complete setup</Button>
      </FooterBar>
    </div>
  );
}

// ─── Step 8 · Welcome & Training ────────────────────────────────────────
function StepWelcome({ onNext, onBack }) {
  const [leads, setLeads] = useS2(30);
  const [installs, setInstalls] = useS2(12);
  const [revenue, setRevenue] = useS2(65000);

  const resources = [
    { t: 'Quick start guide', d: '15-min walkthrough — portal, pipeline, first proposal', icon: 'Book', time: '15 min' },
    { t: 'Video tutorials', d: 'Six short clips on AI Co-Pilot, grants, and PPA', icon: 'Chart', time: '32 min' },
    { t: 'API documentation', d: 'Webhooks, REST, and Solis ingestion', icon: 'Plug', time: 'Reference' },
    { t: '1-on-1 onboarding call', d: 'Book a 30-min session with your CSM', icon: 'Team', time: 'Bookable' },
  ];

  return (
    <div className="fade-up">
      <SectionHead eyebrow="08 · Training" title="Welcome aboard, Sean." desc="Resources to get the most out of SolarPilot. Your success metrics are stored to benchmark your trial." />

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8, marginBottom: 18 }}>
        {resources.map(r => {
          const IconC = Icon[r.icon];
          return (
            <Card key={r.t} interactive style={{ padding: 16 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                <div style={{
                  width: 32, height: 32, borderRadius: 6,
                  background: 'var(--bg-2)', border: '1px solid var(--line-soft)',
                  display: 'grid', placeItems: 'center', color: 'var(--solar)',
                }}>
                  <IconC size={14} />
                </div>
                <Badge tone="neutral">{r.time}</Badge>
              </div>
              <div style={{ fontSize: 13.5, fontWeight: 500, letterSpacing: '-0.01em' }}>{r.t}</div>
              <div style={{ fontSize: 11.5, color: 'var(--ink-4)', marginTop: 4, lineHeight: 1.45 }}>{r.d}</div>
            </Card>
          );
        })}
      </div>

      <Card style={{ padding: 18, marginBottom: 18 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <div>
            <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
              Your success metrics
            </div>
            <div style={{ fontSize: 12, color: 'var(--ink-3)', marginTop: 4 }}>
              We'll check in weekly against these targets.
            </div>
          </div>
          <Badge tone="solar">Editable</Badge>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
          {[
            { label: 'Lead target', val: leads, setter: setLeads, unit: '/ month', min: 5, max: 200, step: 5 },
            { label: 'Installs', val: installs, setter: setInstalls, unit: '/ month', min: 1, max: 60, step: 1 },
            { label: 'Revenue', val: revenue, setter: setRevenue, unit: '€ / month', min: 10000, max: 500000, step: 5000 },
          ].map((m, i) => (
            <div key={i}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
                <span className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>{m.label}</span>
                <span className="mono" style={{ fontSize: 9, color: 'var(--ink-5)' }}>{m.unit}</span>
              </div>
              <div className="tabular" style={{ fontSize: 26, fontWeight: 600, letterSpacing: '-0.025em', color: 'var(--solar)', marginBottom: 8 }}>
                {m.val.toLocaleString()}
              </div>
              <input type="range" min={m.min} max={m.max} step={m.step} value={m.val}
                onChange={e => m.setter(parseInt(e.target.value))}
                style={{ width: '100%', accentColor: 'var(--solar)' }} />
            </div>
          ))}
        </div>
      </Card>

      <FooterBar>
        <Button variant="ghost" onClick={onBack}>Back</Button>
        <Button onClick={() => onNext()} icon={<Icon.Arrow size={14} />}>Continue to portal</Button>
      </FooterBar>
    </div>
  );
}

// ─── Step 9 · Complete ──────────────────────────────────────────────────
function StepComplete({ data }) {
  const canvasRef = useR2(null);
  const [checks, setChecks] = useS2([]);
  const items = [
    'Log in to your portal',
    'Add remaining team members',
    'Upload your past clients (CSV)',
    'Connect inverter APIs',
    'Book kick-off training call',
  ];
  const togCheck = (i) => setChecks(c => c.includes(i) ? c.filter(x => x !== i) : [...c, i]);

  // Confetti
  useE2(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const parent = canvas.parentElement;
    try {
      const ctx = canvas.getContext('2d');
      const W = canvas.width = parent.offsetWidth;
      const H = canvas.height = parent.offsetHeight;
      const colors = ['#F2CC2E', 'oklch(0.76 0.17 145)', 'oklch(0.78 0.13 65)', '#F2CC2E', '#ffffff'];
      const parts = Array.from({ length: 80 }, () => ({
        x: W / 2 + (Math.random() - 0.5) * 300, y: H * 0.2,
        vx: (Math.random() - 0.5) * 10, vy: -Math.random() * 14 - 4,
        s: Math.random() * 6 + 3, c: colors[Math.floor(Math.random() * colors.length)],
        r: Math.random() * 360, rv: (Math.random() - 0.5) * 10, life: 1,
      }));
      let raf = 0;
      const go = () => {
        ctx.clearRect(0, 0, W, H);
        let alive = false;
        for (const p of parts) {
          if (p.life <= 0) continue;
          alive = true;
          p.vy += 0.32; p.x += p.vx; p.y += p.vy;
          p.r += p.rv; p.life -= 0.008;
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.r * Math.PI / 180);
          ctx.globalAlpha = Math.max(0, p.life);
          ctx.fillStyle = p.c;
          ctx.fillRect(-p.s / 2, -p.s / 2, p.s, p.s * 0.6);
          ctx.restore();
        }
        if (alive) raf = requestAnimationFrame(go);
      };
      const t = setTimeout(go, 200);
      return () => { clearTimeout(t); cancelAnimationFrame(raf); };
    } catch {}
  }, []);

  return (
    <div className="fade-up" style={{ position: 'relative' }}>
      <canvas ref={canvasRef} style={{
        position: 'absolute', top: 0, left: 0, width: '100%', height: 320,
        pointerEvents: 'none', zIndex: 5,
      }} />

      <div style={{ textAlign: 'center', marginBottom: 28, position: 'relative' }}>
        <div style={{
          display: 'inline-grid', placeItems: 'center',
          width: 72, height: 72, borderRadius: '50%',
          background: 'var(--solar-soft)', border: '1px solid oklch(0.70 0.17 95 / 0.3)',
          marginBottom: 16,
          color: 'var(--solar)',
        }}>
          <Icon.Check size={28} />
        </div>
        <div className="mono" style={{ fontSize: 10.5, color: 'var(--solar)', letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 8, fontWeight: 500 }}>
          Setup complete
        </div>
        <h1 style={{ fontSize: 36, fontWeight: 600, letterSpacing: '-0.03em', margin: '0 0 8px', lineHeight: 1.1 }}>
          You're all set, <span style={{ color: 'var(--solar)' }}>{(data.contact_name || 'Sean').split(' ')[0]}</span>.
        </h1>
        <p style={{ fontSize: 14, color: 'var(--ink-3)', margin: 0, maxWidth: 400, marginLeft: 'auto', marginRight: 'auto', lineHeight: 1.5 }}>
          Your SolarPilot portal is provisioned and your first qualified leads are being routed.
        </p>
      </div>

      {/* Portal handoff */}
      <Card tone="raised" style={{ padding: 18, marginBottom: 16 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, alignItems: 'center' }}>
          <div>
            <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 6 }}>
              Your portal
            </div>
            <div className="mono" style={{ fontSize: 15, color: 'var(--solar)', fontWeight: 500, letterSpacing: '-0.005em' }}>
              app.solarpilot.renewably.ie
            </div>
            <div style={{ fontSize: 11.5, color: 'var(--ink-4)', marginTop: 4 }}>
              Login link sent to {data.email || 'sean@powersolarltd.ie'}
            </div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <Button size="lg" icon={<Icon.Arrow size={14} />}>Open my portal</Button>
          </div>
        </div>
      </Card>

      {/* Stats tiles */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 8, marginBottom: 16 }}>
        {[
          { k: 'Counties', v: (data.counties || ['Dublin','Kildare','Meath','Wicklow','Wexford','Louth']).length, u: 'service area' },
          { k: 'Team seats', v: 2, u: 'provisioned' },
          { k: 'Plan', v: 'Pro', u: 'annual · €3,490/yr' },
        ].map((s, i) => (
          <Card key={i} style={{ padding: 14 }}>
            <div className="mono" style={{ fontSize: 9.5, color: 'var(--ink-4)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 6 }}>{s.k}</div>
            <div className="tabular" style={{ fontSize: 22, fontWeight: 600, letterSpacing: '-0.025em' }}>{s.v}</div>
            <div style={{ fontSize: 10.5, color: 'var(--ink-4)', marginTop: 2 }}>{s.u}</div>
          </Card>
        ))}
      </div>

      {/* Checklist */}
      <Card style={{ padding: 16 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
            Next steps · first week
          </div>
          <div className="mono" style={{ fontSize: 10, color: 'var(--solar)' }}>
            {checks.length} / {items.length} done
          </div>
        </div>
        <div style={{ display: 'grid', gap: 2 }}>
          {items.map((item, i) => {
            const on = checks.includes(item);
            return (
              <label key={item} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '9px 10px',
                borderRadius: 5, cursor: 'pointer',
                background: on ? 'var(--bg-2)' : 'transparent',
                transition: 'background 140ms',
              }}>
                <input type="checkbox" checked={on} onChange={() => togCheck(item)} />
                <span className="mono" style={{ fontSize: 10.5, color: 'var(--ink-5)', letterSpacing: '0.04em' }}>
                  {String(i + 1).padStart(2, '0')}
                </span>
                <span style={{
                  fontSize: 13,
                  color: on ? 'var(--ink-4)' : 'var(--ink-2)',
                  textDecoration: on ? 'line-through' : 'none',
                  textDecorationColor: 'var(--ink-4)',
                }}>
                  {item}
                </span>
              </label>
            );
          })}
        </div>
      </Card>
    </div>
  );
}

Object.assign(window, { StepLegal, StepFinancial, StepTechnical, StepWelcome, StepComplete });
